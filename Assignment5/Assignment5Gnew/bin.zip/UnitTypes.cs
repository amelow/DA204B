﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 * Amelie Löwe
 * Assignment 5
 * introduction to C# course at the university of Malmö
 */
namespace Assignment5G
{
  public enum UnitTypes //All the enum types
    {
        cm,
        ft,
        g,
        gallon,
        inch,
        kg,
        lb,
        lit,
        m,
        oz,
        piece
    }
}
