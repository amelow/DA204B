﻿using System;
namespace Assignment2.Properties{
/*
 * Second assignment for the Introduction to C#(DA204B) course at the University of Malmö.
 * Author: Amelie Löwe
 * Date: 2019-02-11. 
 */
    public class Input{
    /*
    * This class is meant to be a helper class.
    * Containing shared methods for converting string expression to their corresponding numeric numbers.
    */
        public static int ReadIntegerConsole(){
        }
        public static double ReadDoubleConsole(){

    }
}
