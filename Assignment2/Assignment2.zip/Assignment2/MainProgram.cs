﻿using System;

namespace Assignment2{
/*
 * Second assignment for the Introduction to C#(DA204B) course at the University of Malmö.
 * Author: Amelie Löwe
 * Date: 2019-02-11. 
 */
    class MainClass
    {
        public static void Main(string[] args)
        {
            Menu menu = new Menu();
            menu.Start();
        }
    }
}
